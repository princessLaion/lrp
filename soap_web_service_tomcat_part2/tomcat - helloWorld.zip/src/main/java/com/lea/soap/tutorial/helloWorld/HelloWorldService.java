package com.lea.soap.tutorial.helloWorld;

public class HelloWorldService {
	
	public String greetings(){
		return "Hello World";
	}
	
}
