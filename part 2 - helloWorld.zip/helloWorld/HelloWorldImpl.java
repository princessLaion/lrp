package com.lea.soap.tutorial.helloWorld;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebService;

/**
 * Mandatory: endpointInterface
 * @WebService is the annotation to define that the class is a webservice
 * @author Lea
 *
 */
@WebService(endpointInterface = "com.lea.soap.tutorial.helloWorld.HelloWorld")
public class HelloWorldImpl implements HelloWorld {
	private HelloWorldService helloWorldService;
	
	HelloWorldImpl (){
		helloWorldService = new HelloWorldService();
	}
	
	@Override
	@WebMethod
	public String greetings() {
		return helloWorldService.greetings();
	}

	@Override
	@WebMethod
	public boolean addEmployee(HelloWorldEmployee employee) {
		return helloWorldService.addEmployee(employee);
	}

	@Override
	@WebMethod
	public List<HelloWorldEmployee> retrieveEmployeeList() {
		return helloWorldService.retrieveEmployeeList();
	}

	@Override
	public HelloWorldEmployee retrieveEmployee(String fName) {
		return helloWorldService.retrieveEmployee(fName);
	}
	
	public boolean deleteEmployee (String fName) {
		return helloWorldService.deleteEmployee (fName);
	}

}
