package com.lea.soap.tutorial.helloWorld;

import com.lea.soap.tutorial.helloWorld.wsdl.HelloWorldImplService;

public class HelloWorldClientWSDL {

	public static void main(String[] args) {

		HelloWorldImplService helloService = new HelloWorldImplService();
		HelloWorld hello = helloService.getHelloWorldImplPort();

		System.out.println(hello.greetings());
		System.out.println(hello.retrieveEmployeeList());
		
		hello.deleteEmployee("dummy");
		
		hello.addEmployee( new HelloWorldEmployee("James", "Corden", 30));
		hello.addEmployee( new HelloWorldEmployee("James 1", "Corden 1", 30));		
		
		System.out.println("Retrieving added employee: " + hello.retrieveEmployee("James 1").getlName());
		
		hello.deleteEmployee("James 1");
		
		System.out.println("Retrieving recently deleted employee: " + hello.retrieveEmployee("James 1").getlName());
		
    }
	

}
