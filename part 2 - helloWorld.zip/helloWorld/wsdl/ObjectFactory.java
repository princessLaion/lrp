
package com.lea.soap.tutorial.helloWorld.wsdl;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.lea.soap.tutorial.helloworld package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _RetrieveEmployee_QNAME = new QName("http://helloWorld.tutorial.soap.lea.com/", "retrieveEmployee");
    private final static QName _RetrieveEmployeeList_QNAME = new QName("http://helloWorld.tutorial.soap.lea.com/", "retrieveEmployeeList");
    private final static QName _DeleteEmployeeResponse_QNAME = new QName("http://helloWorld.tutorial.soap.lea.com/", "deleteEmployeeResponse");
    private final static QName _GreetingsResponse_QNAME = new QName("http://helloWorld.tutorial.soap.lea.com/", "greetingsResponse");
    private final static QName _RetrieveEmployeeResponse_QNAME = new QName("http://helloWorld.tutorial.soap.lea.com/", "retrieveEmployeeResponse");
    private final static QName _RetrieveEmployeeListResponse_QNAME = new QName("http://helloWorld.tutorial.soap.lea.com/", "retrieveEmployeeListResponse");
    private final static QName _AddEmployee_QNAME = new QName("http://helloWorld.tutorial.soap.lea.com/", "addEmployee");
    private final static QName _AddEmployeeResponse_QNAME = new QName("http://helloWorld.tutorial.soap.lea.com/", "addEmployeeResponse");
    private final static QName _DeleteEmployee_QNAME = new QName("http://helloWorld.tutorial.soap.lea.com/", "deleteEmployee");
    private final static QName _Greetings_QNAME = new QName("http://helloWorld.tutorial.soap.lea.com/", "greetings");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.lea.soap.tutorial.helloworld
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GreetingsResponse }
     * 
     */
    public GreetingsResponse createGreetingsResponse() {
        return new GreetingsResponse();
    }

    /**
     * Create an instance of {@link RetrieveEmployeeResponse }
     * 
     */
    public RetrieveEmployeeResponse createRetrieveEmployeeResponse() {
        return new RetrieveEmployeeResponse();
    }

    /**
     * Create an instance of {@link RetrieveEmployeeListResponse }
     * 
     */
    public RetrieveEmployeeListResponse createRetrieveEmployeeListResponse() {
        return new RetrieveEmployeeListResponse();
    }

    /**
     * Create an instance of {@link DeleteEmployeeResponse }
     * 
     */
    public DeleteEmployeeResponse createDeleteEmployeeResponse() {
        return new DeleteEmployeeResponse();
    }

    /**
     * Create an instance of {@link RetrieveEmployee }
     * 
     */
    public RetrieveEmployee createRetrieveEmployee() {
        return new RetrieveEmployee();
    }

    /**
     * Create an instance of {@link RetrieveEmployeeList }
     * 
     */
    public RetrieveEmployeeList createRetrieveEmployeeList() {
        return new RetrieveEmployeeList();
    }

    /**
     * Create an instance of {@link Greetings }
     * 
     */
    public Greetings createGreetings() {
        return new Greetings();
    }

    /**
     * Create an instance of {@link AddEmployeeResponse }
     * 
     */
    public AddEmployeeResponse createAddEmployeeResponse() {
        return new AddEmployeeResponse();
    }

    /**
     * Create an instance of {@link DeleteEmployee }
     * 
     */
    public DeleteEmployee createDeleteEmployee() {
        return new DeleteEmployee();
    }

    /**
     * Create an instance of {@link AddEmployee }
     * 
     */
    public AddEmployee createAddEmployee() {
        return new AddEmployee();
    }

    /**
     * Create an instance of {@link HelloWorldEmployee }
     * 
     */
    public HelloWorldEmployee createHelloWorldEmployee() {
        return new HelloWorldEmployee();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveEmployee }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://helloWorld.tutorial.soap.lea.com/", name = "retrieveEmployee")
    public JAXBElement<RetrieveEmployee> createRetrieveEmployee(RetrieveEmployee value) {
        return new JAXBElement<RetrieveEmployee>(_RetrieveEmployee_QNAME, RetrieveEmployee.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveEmployeeList }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://helloWorld.tutorial.soap.lea.com/", name = "retrieveEmployeeList")
    public JAXBElement<RetrieveEmployeeList> createRetrieveEmployeeList(RetrieveEmployeeList value) {
        return new JAXBElement<RetrieveEmployeeList>(_RetrieveEmployeeList_QNAME, RetrieveEmployeeList.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteEmployeeResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://helloWorld.tutorial.soap.lea.com/", name = "deleteEmployeeResponse")
    public JAXBElement<DeleteEmployeeResponse> createDeleteEmployeeResponse(DeleteEmployeeResponse value) {
        return new JAXBElement<DeleteEmployeeResponse>(_DeleteEmployeeResponse_QNAME, DeleteEmployeeResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GreetingsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://helloWorld.tutorial.soap.lea.com/", name = "greetingsResponse")
    public JAXBElement<GreetingsResponse> createGreetingsResponse(GreetingsResponse value) {
        return new JAXBElement<GreetingsResponse>(_GreetingsResponse_QNAME, GreetingsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveEmployeeResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://helloWorld.tutorial.soap.lea.com/", name = "retrieveEmployeeResponse")
    public JAXBElement<RetrieveEmployeeResponse> createRetrieveEmployeeResponse(RetrieveEmployeeResponse value) {
        return new JAXBElement<RetrieveEmployeeResponse>(_RetrieveEmployeeResponse_QNAME, RetrieveEmployeeResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RetrieveEmployeeListResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://helloWorld.tutorial.soap.lea.com/", name = "retrieveEmployeeListResponse")
    public JAXBElement<RetrieveEmployeeListResponse> createRetrieveEmployeeListResponse(RetrieveEmployeeListResponse value) {
        return new JAXBElement<RetrieveEmployeeListResponse>(_RetrieveEmployeeListResponse_QNAME, RetrieveEmployeeListResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddEmployee }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://helloWorld.tutorial.soap.lea.com/", name = "addEmployee")
    public JAXBElement<AddEmployee> createAddEmployee(AddEmployee value) {
        return new JAXBElement<AddEmployee>(_AddEmployee_QNAME, AddEmployee.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AddEmployeeResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://helloWorld.tutorial.soap.lea.com/", name = "addEmployeeResponse")
    public JAXBElement<AddEmployeeResponse> createAddEmployeeResponse(AddEmployeeResponse value) {
        return new JAXBElement<AddEmployeeResponse>(_AddEmployeeResponse_QNAME, AddEmployeeResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link DeleteEmployee }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://helloWorld.tutorial.soap.lea.com/", name = "deleteEmployee")
    public JAXBElement<DeleteEmployee> createDeleteEmployee(DeleteEmployee value) {
        return new JAXBElement<DeleteEmployee>(_DeleteEmployee_QNAME, DeleteEmployee.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Greetings }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://helloWorld.tutorial.soap.lea.com/", name = "greetings")
    public JAXBElement<Greetings> createGreetings(Greetings value) {
        return new JAXBElement<Greetings>(_Greetings_QNAME, Greetings.class, null, value);
    }

}
