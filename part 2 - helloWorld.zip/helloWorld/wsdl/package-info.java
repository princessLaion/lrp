@javax.xml.bind.annotation.XmlSchema(namespace = "http://helloWorld.tutorial.soap.lea.com/")
package com.lea.soap.tutorial.helloWorld.wsdl;
