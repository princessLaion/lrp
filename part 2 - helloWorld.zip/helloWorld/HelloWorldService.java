package com.lea.soap.tutorial.helloWorld;

import java.util.ArrayList;
import java.util.List;

public class HelloWorldService {

	List<HelloWorldEmployee> employeeList = new ArrayList<>();
	
	public String greetings(){
		return "Hello World";
	}
	
	public boolean addEmployee(HelloWorldEmployee employee) {
		if(employee == null) {
			System.out.println("Employee was null");
			return false;
		}
		employeeList.add(new HelloWorldEmployee (employee.getfName(), employee.getlName(), employee.getAge()));
		return true;
	}

	public List<HelloWorldEmployee> retrieveEmployeeList() {
		System.out.println("Employee size: " + employeeList.size());
		return employeeList;
	}
	
	public HelloWorldEmployee retrieveEmployee(String fName) {
		HelloWorldEmployee hwEmployee = new HelloWorldEmployee();
		if(employeeList.isEmpty()) {
			return hwEmployee;
		}
		
		for(HelloWorldEmployee employee : employeeList) {
			if( fName.equalsIgnoreCase( employee.getfName() ) ) {
				hwEmployee = employee;
				break;
			}
		}
		
		return hwEmployee;
	}
	
	public boolean deleteEmployee (String fName) {
		boolean isEmployeeDeleted = false;
		
		if(!employeeList.isEmpty()) {
			for(HelloWorldEmployee employee : employeeList) {
				if( fName.equalsIgnoreCase( employee.getfName() ) ) {
					employeeList.remove(employee);
					isEmployeeDeleted = true;
					break;
				}
			}
		}
		return isEmployeeDeleted;
	}
	
	
	
	
}
